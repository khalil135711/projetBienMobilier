package models;

public enum Role {
	ADMIN,PROFESSEUR,ETUDIANT;
}
